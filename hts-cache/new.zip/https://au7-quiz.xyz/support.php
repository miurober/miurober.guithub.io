<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Apoio, suporte</title>
  <link rel="stylesheet" href="./public/common.css?v=1007">
  <script src="./public/jquery-3.6.0.min.js"></script>
  <script src="./public/sweetalert-dev.js?v=1007"></script>
 <link rel="stylesheet" href="./public/sweetalert.css">
 </head>

<body>
  <div class="Fc bfb">
    <div class="mainbody">

    
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-174943768-10"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-174943768-10');
  // Feature detects Navigation Timing API support.
  if (window.performance) {
    // Gets the number of milliseconds since page load
    // (and rounds the result since the value must be an integer).
    var timeSincePageLoad = Math.round(performance.now());
    // Sends the timing event to Google Analytics.
    gtag("event", "timing_complete", {
      name: "load",
      value: timeSincePageLoad,
      event_category: "JS Dependencies",
    });
  }
  var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?d21f73c340dce61cc716692c31315c81";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
  

var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?5bca69326d411f4514e25b24cf9d3904";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();


  function errorfunction(errorcode){
    error=geterrorfromcode(errorcode,errorcodes);
    oldhtml=$("#"+regim+"title").html();
    $("#"+regim+"title").html("<font color='red'><b>"+error+"</b></font>");
    focuserrorfield(regim+"f",errorcode,errorcodes);
    setTimeout(clearerror,2000);
  }

  function successfunction(){
      loc="userarea.php";
      if (regim=="writemess"){loc="support.php";}
      document.location=loc;
  }

  function clearerror(){
    $("#"+regim+"title").html(oldhtml);
  }
</script>
<div id='share_word' style="display:none">E se você tiver uma chance de um milhão de libras?  Você pode querer saber o quão forte você é e quanto dinheiro pode ganhar.  Venha e participe!  !  !</div>

<div id="menu" class="Frl mu" onclick="closeMenu()">
        <div class="Fct mu-content" onclick="stopClick()">
          <div class="Fct mu-top">
            <div class="Frl mu-top-mid">
              <div class="Fc mu-top-head">
                <img id="userHead" class="mu-top-img" src="img/head.png" alt="">
              </div>
              <div class="mu-top-in">
			  
			                <div id="userName" class="Tes mu-top-name"></div>
                <div id="userEmail" class="Tes mu-top-email">Área do usuário</div>
							
              </div>
            </div>
          </div>
          <div class="Fc mu-list">
            <div class="Frl mu-item" onclick="menuHome()">
              <img class="mu-item-icon" src="./img/Answer_pc_Home.png" alt="">
              <span class="mu-item-name">Página principal</span>
            </div>
            <div class="Frl mu-item" onclick="menuUserArea()">
              <img class="mu-item-icon" src="./img/Answer_pc_User-area.png" alt="">
              <span class="mu-item-name">Área do usuário</span>
            </div>
            <div class="Frl mu-item" onclick="menuSupport()">
              <img class="mu-item-icon" src="./img/Answer_pc_Support.png" alt="">
              <span class="mu-item-name">Apoio, suporte</span>
            </div>
            <div class="Frl mu-item" onclick="menuFAQ()">
              <img class="mu-item-icon" src="./img/Answer_pc_F.A.Q.png" alt="">
              <span class="mu-item-name">PERGUNTAS FREQUENTES</span>
            </div>
			<div class="Frl mu-item" onclick="menuLanguage()">
              <img class="mu-item-icon" src="./img/Answer_pc_Language.png" alt="">
              <span class="mu-item-name">Language</span>
            </div>
            <div class="Frl mu-item" onclick="menuRule()">
              <img class="mu-item-icon" src="./img/Answer_pc_Rules.png" alt="">
              <span class="mu-item-name">Regras</span>
            </div>
			            <button class="mu-out" onclick="menusignin()">Entrar</button>
			<button class="mu-out" onclick="menusignup()">Inscrever-se</button>
			          </div>
        </div>
      </div>

  <link rel="stylesheet" href="public/toastr.min.css?2">
<link rel="stylesheet" href="public/ext-component-toastr.css?2">
<script src="public/vendors.min.js"></script>

<script src="public/toastr.min.js"></script>
<style>
h5,h6{font-size:16px;}
.fw-bolder {
  font-weight: 600 !important;
}
.text-success {
 position:absolute;
  color: #28c76f !important;
}
.text-success1 {
  color: #28c76f !important;
}
.p-25 {
  padding: 0.25rem !important;
}
.text-uppercase {
  text-transform: uppercase !important;
}
.text-primary {
  color: #7367f0 !important;
}


</style>
<script>
        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
        function showToast() {
            $.get('fetch.php', function(d) {
				console.log(d)
                if(d.success === true) {
                    toastr.remove();
					toastr['success']("<h6 class='p-25'> <span class='fw-bolder text-primary text-uppercase'>" + d.toast.name + "</span> acabou de pagar <strong class='text-success1'>$" + numberWithCommas(toast_amount()) + "</strong> através da <strong class='text-primary'>" + d.toast.method + "</strong>!</h6>", "<h5 class='text-success fw-bolder'>Novo pagamento enviado:</h5>", {
                      "closeButton": true,
                      tapToDismiss: true,
                      progressBar: true,
                      "showDuration": "300",
                      "hideDuration": "1000",
                      "timeOut": "7000",
                      "positionClass": 'toast-bottom-center',
                      "extendedTimeOut": "1000",
                      "showMethod": "slideDown"
                    });
                }
            },"json");
        }
        function doToast(secs) {
            setInterval(function(){ toastr.remove();showToast(); }, secs);
        }
        // function toast_seconds() {
        //     return (Math.floor(Math.random() * (+50 - +30) + +30))*1000;
        // }
        function toast_amount() {
            return Math.floor(Math.random() * (+2500 - +500) + +500).toFixed(0);
        }
        function randomIntFromInterval(min, max) { // min and max included 
          return Math.floor(Math.random() * (max - min + 1) + min);
        }

			//toastr.remove();
           // showToast();
        setTimeout(function(){ 
            toastr.remove();
            showToast();
            doToast(randomIntFromInterval(30, 50)*1000);
        }, randomIntFromInterval(5, 15) * 1000);
</script>
         <div id="contactSend" class="Fc ctt-mask" onclick="closeSend()">
        <div class="Fc ctt-mask-mid">
          <div class="ctt-shell-textarea" onclick="stopClick()">
            <textarea id="textareaVal" class="ctt-textarea" rows="6"
              placeholder="Digite a pergunta que deseja fazer"></textarea>
          </div>
          <button class="ctt-send-btn" onclick="clickSend()">Send</button>
        </div>
      </div>
      <div class="Fct maincontent">
        <div class="Frl cont-top">
          <img class="cont-top-menu" src="./img/Answer_7.png" onclick="openMenu()">
          <span class="cont-top-title">Cardápio</span>
          <div class="Frr ctt-top" style="text-align: right;">
            <img class="ctt-top-icon" src="./img/Answer_18.png" alt="" onclick="openSend()">
          </div>
        </div>
        <div class="Fc ctt">
          
          <div class="Fct ctt-white">
            <div id="contactList" class="Fc ctt-content"></div>
          </div>
          <footer class="Fc rec" style="position:relative;width:100%;margin-bottom:1rem;height:1rem;">
              <div class="rec-text Fc" style="color:#ffffff;">
              direito autoral &copy; au7-quiz.xyz 2007-2021
              </div>

          </footer>
        </div>
      </div>
    </div>
  </div>
  </div>
</body>

<!-- 菜单事件 -->
<script src="./public/common.js"></script>

<script>
function clickSend() {
    event.stopPropagation();
    let textareaVal = $("#textareaVal").val();
	$.post("support.php",{message:textareaVal},function(result){
			if(result.code==1){

				swal({title:"Seu feedback foi recebido, por favor, aguarde pacientemente e continue a ganhar dinheiro",type:"success",button: " OK "},function(){window.location.href="./"});
			}else{

				swal({title:result.message,type:"warning",button: " OK "});
			}
		});
    //$("#contactSend").css('display', 'none')
  }
  
  

		
  let contactArr = [
    	
    { problem: "<b style='color:green'>HelenaGilmore2000: </b>Simplesmente não há palavras, estou em choque !!!  Ela ganhou 800 dólares, mas não tinha referências suficientes, decidiu comprar na bolsa.  Comprei um código por 12 dólares, os referidos chegaram imediatamente, e após 5 minutos recebi uma mensagem sobre reabastecimento do meu cartão por 800 dólares. Nossa, nossa, nossa, quero gritar de felicidade, não acreditei até o último  momento em que receberia pagamentos !!!  Escreva se você tiver dúvidas, terei o maior prazer em responder a todos!", answer: "<b style='color:red'>Resposta do administrador: </b>Esperando resposta..." },
    	
    { problem: "<b style='color:green'>Vlad2000: </b>Estou chocado !!!  Trouxe 30 referidos e imediatamente recebi dinheiro na conta Os referidos foram convidados através das redes sociais e do sistema NeoBux", answer: "<b style='color:red'>Resposta do administrador: </b>Esperando resposta..." },
    	
    { problem: "<b style='color:green'>Helga2000: </b>Viva!  Peguei o valor mínimo e recebi dinheiro na minha conta!", answer: "<b style='color:red'>Resposta do administrador: </b>Esperando resposta..." },
    	
    { problem: "<b style='color:green'>Raymonds: </b>Olá pessoal!  Meu amigo me aconselhou a me juntar a você e eu fiz!  Pelo dinheiro que ganhou com você, ele conseguiu comprar um novo iPhone!", answer: "<b style='color:red'>Resposta do administrador: </b>Esperando resposta..." },
    	
    { problem: "<b style='color:green'>VioricaD89: </b>Uau!  Que grande projeto é!  Agradeço aos organizadores.  Já retirei meus primeiros ganhos!  E a soma de 177 dólares é muito boa para um aluno como eu", answer: "<b style='color:red'>Resposta do administrador: </b>Olá, VioricaD89!  Obrigado pelo trabalho e boa sorte!" },
    	
    { problem: "<b style='color:green'>Magist2000: </b>É muito bom, estou te dizendo.  Logo no primeiro dia ganhei uma quantia decente de 93 dólares e pensei que não seria capaz de sacar.  No entanto, decidi pedir o pagamento e, voilà, recebi o dinheiro depois de 3 minutos, verifiquei!", answer: "<b style='color:red'>Resposta do administrador: </b>Hello Magist2000!  Sim, não temos atrasos nos pagamentos e pagamos sempre a pedido do utilizador!" },
    	
    { problem: "<b style='color:green'>Orqefaxx: </b>Olá pessoal!  Ontem já retirei algum dinheiro do cartão do banco pela segunda vez.  Agora eu tenho uma pergunta: eu preciso pagar impostos com o dinheiro retirado？ Como？", answer: "<b style='color:red'>Resposta do administrador: </b>Boa tarde, Orqefaxx.  Somos um agente tributário, portanto, pagamos impostos por você, ou seja, você recebe o valor final.  Você não tem nada com o que se preocupar" },
    	
    { problem: "<b style='color:green'>Kattia: </b>Na semana passada, um amigo me enviou o link no Facebook.  Desde então, retirei mais de 200 dólares!  E não é nem fim de semana!  Estou chocado!  Muito obrigado aos administradores!", answer: "<b style='color:red'>Resposta do administrador: </b>Obrigado, Kattia, por suas amáveis ​​palavras!  Estaremos ansiosos para trabalhar com você no futuro!" },
    	
    { problem: "<b style='color:green'>Germiona: </b>Prometi escrever um feedback, então aqui estou.  Acabei de receber uma mensagem informando que meu dinheiro 【196 dólares】 foi retirado para meu cartão de banco.  Muito obrigado!", answer: "<b style='color:red'>Resposta do administrador: </b>Germiona, não poderia ser de outra forma!" },
    	
    { problem: "<b style='color:green'>Dennyboy: </b>Excelente!  Recebi os 315 dólares ontem.  Há o suficiente para comprar um smartphon novo e mais poderoso", answer: "<b style='color:red'>Resposta do administrador: </b>Caro Dennyboy, obrigado pelo feedback!" },
    	
    { problem: "<b style='color:green'>alex_guss: </b>Você planeja adicionar o sistema de pagamento Payoneer？ Eu moro na Alemanha e este método seria mais conveniente para mim.", answer: "<b style='color:red'>Resposta do administrador: </b>Olá alex_guss!  Estamos trabalhando nessa direção.  Informaremos você sobre isso assim que soubermos." },
    	
    { problem: "<b style='color:green'>Bachhj122: </b>Ofereci minha esposa e filha para experimentá-lo e eles já ganharam 420 dólares grandes somas!", answer: "<b style='color:red'>Resposta do administrador: </b>Obrigado Bachhj122!  Atraia seus amigos também" },
    	
    { problem: "<b style='color:green'>ivonna_att: </b>É um ótimo trabalho de meio período para mães em licença maternidade!  Atraio amigos e ganho cerca de 350 dólares por semana!", answer: "<b style='color:red'>Resposta do administrador: </b>ivonna_att, desejamos que você obtenha ainda mais ganhos !!" },
    	
    { problem: "<b style='color:green'>amaretto: </b>Hum, nada mal.  Ainda ontem, retirei minhas quantias de 174 dólares.  Agora não preciso mais ser taxista.", answer: "<b style='color:red'>Resposta do administrador: </b>amaretto, obrigado pela sua confiança" },
    	
    { problem: "<b style='color:green'>Patricia56: </b>Obrigado, está tudo bem.  Retirei meus fundos sem problemas!", answer: "<b style='color:red'>Resposta do administrador: </b>Patricia56, boa sorte com seu trabalho !!" },
    	
    { problem: "<b style='color:green'>Patricia56: </b>meu email [email protegido]", answer: "<b style='color:red'>Resposta do administrador: </b>As instruções foram enviadas" },
    	
    { problem: "<b style='color:green'>margo777: </b>Estou chocado.  Agora estou pensando em deixar meu trabalho principal.  Em apenas dois dias ganhei o valor igual ao meu salário mensal!  A questão é: quanto tempo vai durar？", answer: "<b style='color:red'>Resposta do administrador: </b>Boa tarde margo777!  Temos muitos pedidos e os orçamentos estão aprovados até o final de 2025. Não se preocupe!  Você terá trabalho a fazer!" },
    	
    { problem: "<b style='color:green'>Patricia56: </b>Não consigo entender como sacar dinheiro para um cartão de banco.  Por favor me ajude.  Minha irmã fez isso não faz muito tempo, e eu não posso!", answer: "<b style='color:red'>Resposta do administrador: </b>Patricia56, por favor, escreva seu e-mail, e nós lhe enviaremos todas as instruções detalhadas." },
    	
  ];
  let contactStr = '';
  $.each(contactArr, (i, v) => {
    contactStr += `<div class="Fc ctt-item">
      <div class="ctt-item-pro">${contactArr[i].problem}</div>
      <div class="ctt-item-ans">${contactArr[i].answer}</div>
    </div>`
  });
  $("#contactList").append(contactStr);
  function openSend() {
    $("#contactSend").css('display', 'block')
  }

  function closeSend() {
    $("#contactSend").css('display', 'none')
  }

  function stopClick() {
    event.stopPropagation();
  }

  
</script>

</html>
