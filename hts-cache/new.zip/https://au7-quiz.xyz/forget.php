<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Esqueceu a senha</title>
  <link rel="stylesheet" href="./public/common.css?v=1007">
  <script src="./public/jquery-3.6.0.min.js"></script>
  <script src="./public/common.js?v=1007"></script>
  <script src="./public/sweetalert-dev.js?v=1007"></script>
 <link rel="stylesheet" href="./public/sweetalert.css">
 </head>


<body>

  <div class="Fc bfb">
    <div class="mainbody">
	
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-174943768-10"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-174943768-10');
  // Feature detects Navigation Timing API support.
  if (window.performance) {
    // Gets the number of milliseconds since page load
    // (and rounds the result since the value must be an integer).
    var timeSincePageLoad = Math.round(performance.now());
    // Sends the timing event to Google Analytics.
    gtag("event", "timing_complete", {
      name: "load",
      value: timeSincePageLoad,
      event_category: "JS Dependencies",
    });
  }
  var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?d21f73c340dce61cc716692c31315c81";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
  

var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?5bca69326d411f4514e25b24cf9d3904";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();


  function errorfunction(errorcode){
    error=geterrorfromcode(errorcode,errorcodes);
    oldhtml=$("#"+regim+"title").html();
    $("#"+regim+"title").html("<font color='red'><b>"+error+"</b></font>");
    focuserrorfield(regim+"f",errorcode,errorcodes);
    setTimeout(clearerror,2000);
  }

  function successfunction(){
      loc="userarea.php";
      if (regim=="writemess"){loc="support.php";}
      document.location=loc;
  }

  function clearerror(){
    $("#"+regim+"title").html(oldhtml);
  }
</script>
<div id='share_word' style="display:none">E se você tiver uma chance de um milhão de libras?  Você pode querer saber o quão forte você é e quanto dinheiro pode ganhar.  Venha e participe!  !  !</div>

<div id="menu" class="Frl mu" onclick="closeMenu()">
        <div class="Fct mu-content" onclick="stopClick()">
          <div class="Fct mu-top">
            <div class="Frl mu-top-mid">
              <div class="Fc mu-top-head">
                <img id="userHead" class="mu-top-img" src="img/head.png" alt="">
              </div>
              <div class="mu-top-in">
			  
			                <div id="userName" class="Tes mu-top-name"></div>
                <div id="userEmail" class="Tes mu-top-email">Área do usuário</div>
							
              </div>
            </div>
          </div>
          <div class="Fc mu-list">
            <div class="Frl mu-item" onclick="menuHome()">
              <img class="mu-item-icon" src="./img/Answer_pc_Home.png" alt="">
              <span class="mu-item-name">Página principal</span>
            </div>
            <div class="Frl mu-item" onclick="menuUserArea()">
              <img class="mu-item-icon" src="./img/Answer_pc_User-area.png" alt="">
              <span class="mu-item-name">Área do usuário</span>
            </div>
            <div class="Frl mu-item" onclick="menuSupport()">
              <img class="mu-item-icon" src="./img/Answer_pc_Support.png" alt="">
              <span class="mu-item-name">Apoio, suporte</span>
            </div>
            <div class="Frl mu-item" onclick="menuFAQ()">
              <img class="mu-item-icon" src="./img/Answer_pc_F.A.Q.png" alt="">
              <span class="mu-item-name">PERGUNTAS FREQUENTES</span>
            </div>
			<div class="Frl mu-item" onclick="menuLanguage()">
              <img class="mu-item-icon" src="./img/Answer_pc_Language.png" alt="">
              <span class="mu-item-name">Language</span>
            </div>
            <div class="Frl mu-item" onclick="menuRule()">
              <img class="mu-item-icon" src="./img/Answer_pc_Rules.png" alt="">
              <span class="mu-item-name">Regras</span>
            </div>
			            <button class="mu-out" onclick="menusignin()">Entrar</button>
			<button class="mu-out" onclick="menusignup()">Inscrever-se</button>
			          </div>
        </div>
      </div>

  <link rel="stylesheet" href="public/toastr.min.css?2">
<link rel="stylesheet" href="public/ext-component-toastr.css?2">
<script src="public/vendors.min.js"></script>

<script src="public/toastr.min.js"></script>
<style>
h5,h6{font-size:16px;}
.fw-bolder {
  font-weight: 600 !important;
}
.text-success {
 position:absolute;
  color: #28c76f !important;
}
.text-success1 {
  color: #28c76f !important;
}
.p-25 {
  padding: 0.25rem !important;
}
.text-uppercase {
  text-transform: uppercase !important;
}
.text-primary {
  color: #7367f0 !important;
}


</style>
<script>
        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
        function showToast() {
            $.get('fetch.php', function(d) {
				console.log(d)
                if(d.success === true) {
                    toastr.remove();
					toastr['success']("<h6 class='p-25'> <span class='fw-bolder text-primary text-uppercase'>" + d.toast.name + "</span> acabou de pagar <strong class='text-success1'>$" + numberWithCommas(toast_amount()) + "</strong> através da <strong class='text-primary'>" + d.toast.method + "</strong>!</h6>", "<h5 class='text-success fw-bolder'>Novo pagamento enviado:</h5>", {
                      "closeButton": true,
                      tapToDismiss: true,
                      progressBar: true,
                      "showDuration": "300",
                      "hideDuration": "1000",
                      "timeOut": "7000",
                      "positionClass": 'toast-bottom-center',
                      "extendedTimeOut": "1000",
                      "showMethod": "slideDown"
                    });
                }
            },"json");
        }
        function doToast(secs) {
            setInterval(function(){ toastr.remove();showToast(); }, secs);
        }
        // function toast_seconds() {
        //     return (Math.floor(Math.random() * (+50 - +30) + +30))*1000;
        // }
        function toast_amount() {
            return Math.floor(Math.random() * (+2500 - +500) + +500).toFixed(0);
        }
        function randomIntFromInterval(min, max) { // min and max included 
          return Math.floor(Math.random() * (max - min + 1) + min);
        }

			//toastr.remove();
           // showToast();
        setTimeout(function(){ 
            toastr.remove();
            showToast();
            doToast(randomIntFromInterval(30, 50)*1000);
        }, randomIntFromInterval(5, 15) * 1000);
</script>
         <div class="maincontent">
	  
	  <div class="Frl cont-top">
          <img class="cont-top-menu" src="./img/Answer_7.png" onclick="openMenu()">
          <span class="cont-top-title">Cardápio</span>
        </div>
        <div class="Fc sign">
          
          <div class="sign-ep">Esqueceu a senha</div>
          <div class="Fct sign-form" style="height: 6.36rem;">
            <div class="sign-form-name">Nome</div>
            <div class="Fc sign-form-shell">
              <input class="sign-form-input" type="text" placeholder="Type your name" id="name">
            </div>
            <div class="sign-form-name">O email</div>
            <div class="Fc sign-form-shell">
              <input class="sign-form-input" type="text" placeholder="Type your email" id="email">
            </div>
            
            
            <div class="sign-form-blank"></div>
            <button class="sign-form-btn" onclick="forget()">Pegue minha senha</button>
			
            <div class="sign-form-tip">Ao selecionar qualquer uma das opções, você concorda com nossa Privacidade.  Política.  & Termos de uso            </div>
          </div>
          <div class="Fr sign-mid">
            <div class="sign-mid-line1"></div>
            <span class="sign-mid-text">Login via redes sociais</span>
            <div class="sign-mid-line2"></div>
          </div>
          <div class="Frsa sign-icon">
            
			<div id="uLoginreg" data-ulogin="display=panel;theme=classic;fields=first_name,last_name;providers=google,facebook;redirect_uri=https%3A%2F%2Fau7-quiz.xyz%2Fulogin.php;mobilebuttons=0;"></div>
          </div>
          <div class="sign-bottom">
            <span>Mais de 20 milhões de usuários jogaram conosco</span>
          </div>
          <div class="sign-bottom">
            <span> Over 100 quizzes are waiting for you</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="//ulogin.ru/js/ulogin.js"></script>
</body>

<script>

  function forget() {
    let name = $("#name").val()
    let email = $("#email").val()
    let password = $("#password").val()
    let passwordAgain = $("#passwordAgain").val()
    let emailReg = /^([\.a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;
    if (!name) {
      swal({title:'Por favor, insira um nome!',type:"warning",button: " OK "});
    } else if (name.length < 6) {
      swal({title:'O nome deve ter pelo menos 6 caracteres!',type:"warning",button: " OK "});
    } else if (!emailReg.test(email)) {
      swal({title:"Por favor, insira o e-mail correto!",type:"warning",button: " OK "});
    }  else {
      // 注册操作
      console.log(name, email, password, passwordAgain);
		 $.post("api.php?act=forget",{name:name,email:email,password:password},function(result){
			if(result.code==1){

				swal({title:"Parabéns!",text:result.message,type:"success",button: "OK"},function(){window.location.href="./signin.php"});
			}else{

				swal({title:result.message,type:"warning",button: " OK "});
			}
		});

    }
  }





</script>

</html>